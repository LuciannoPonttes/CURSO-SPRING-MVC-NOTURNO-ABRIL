package revisao_api.revisao_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevisaoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevisaoApiApplication.class, args);
	}

}
