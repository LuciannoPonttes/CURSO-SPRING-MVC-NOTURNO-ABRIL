package br.com.impacta.springmvc.gerenciadordespesas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorDespesasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciadorDespesasApplication.class, args);
	}
}
