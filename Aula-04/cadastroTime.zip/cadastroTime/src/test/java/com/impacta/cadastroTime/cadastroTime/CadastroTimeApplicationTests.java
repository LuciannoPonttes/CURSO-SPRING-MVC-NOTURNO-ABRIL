package com.impacta.cadastroTime.cadastroTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
