package com.impacta.cadastroTime.cadastroTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroTimeApplication.class, args);
	}

}
