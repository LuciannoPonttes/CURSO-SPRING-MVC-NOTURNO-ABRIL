package cadastroAnimais.cadastroAnimais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroAnimaisApplicationTests {

	@Test
	void contextLoads() {
	}

}
